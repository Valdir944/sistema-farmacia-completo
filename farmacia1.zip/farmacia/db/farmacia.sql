CREATE TABLE produtos (
    id INT(11) PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(255) NOT NULL,
    descricao TEXT,
    preco DECIMAL(10, 2) NOT NULL,
    quantidade INT(11) NOT NULL,
    codigo_barras VARCHAR(255) UNIQUE
);

CREATE TABLE vendas (
    id INT(11) PRIMARY KEY AUTO_INCREMENT,
    data DATETIME NOT NULL,
    total DECIMAL(10, 2) NOT NULL
);

CREATE TABLE itens_venda (
    id INT(11) PRIMARY KEY AUTO_INCREMENT,
    venda_id INT(11),
    produto_id INT(11),
    quantidade INT(11) NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (venda_id) REFERENCES vendas(id),
    FOREIGN KEY (produto_id) REFERENCES produtos(id)
);