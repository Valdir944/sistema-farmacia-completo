<?php
require_once 'app/funcoes_db.php';

// Função para registrar erros em um log
function logErro($mensagemErro) {
    error_log(date('[Y-m-d H:i:s] ') . $mensagemErro . PHP_EOL, 3, 'erros.log');
}

// Inicializar variáveis
$data_inicio = $_GET['data_inicio'] ?? date('Y-m-01');
$data_fim = $_GET['data_fim'] ?? date('Y-m-d');
$vendas = buscarVendasPorPeriodo($data_inicio, $data_fim);
$total_periodo = 0;
$quantidade_total_itens = 0;
$produtos_vendidos = [];
$relatorio_por_periodo = [
    'diario' => [],
    'semanal' => [],
    'mensal' => [],
    'anual' => []
];

// Processar vendas para calcular totais e produtos vendidos
foreach ($vendas as $venda) {
    $total_periodo += $venda['total'];
    $itens = buscarItensVenda($venda['id']);
    foreach ($itens as $item) {
        $nome = $item['nome'];
        $quantidade = $item['quantidade'];
        $subtotal = $item['subtotal'];
        
        // Agregar quantidade total
        $quantidade_total_itens += $quantidade;

        // Agregar por produto
        if (!isset($produtos_vendidos[$nome])) {
            $produtos_vendidos[$nome] = [
                'quantidade' => 0,
                'subtotal' => 0
            ];
        }
        $produtos_vendidos[$nome]['quantidade'] += $quantidade;
        $produtos_vendidos[$nome]['subtotal'] += $subtotal;

        // Agregar por período
        $data_venda = new DateTime($venda['data']);
        $dia = $data_venda->format('Y-m-d');
        $semana = $data_venda->format('o-W');
        $mes = $data_venda->format('Y-m');
        $ano = $data_venda->format('Y');

        // Diário
        if (!isset($relatorio_por_periodo['diario'][$dia])) {
            $relatorio_por_periodo['diario'][$dia] = ['quantidade' => 0, 'total' => 0];
        }
        $relatorio_por_periodo['diario'][$dia]['quantidade'] += $quantidade;
        $relatorio_por_periodo['diario'][$dia]['total'] += $subtotal;

        // Semanal
        if (!isset($relatorio_por_periodo['semanal'][$semana])) {
            $relatorio_por_periodo['semanal'][$semana] = ['quantidade' => 0, 'total' => 0];
        }
        $relatorio_por_periodo['semanal'][$semana]['quantidade'] += $quantidade;
        $relatorio_por_periodo['semanal'][$semana]['total'] += $subtotal;

        // Mensal
        if (!isset($relatorio_por_periodo['mensal'][$mes])) {
            $relatorio_por_periodo['mensal'][$mes] = ['quantidade' => 0, 'total' => 0];
        }
        $relatorio_por_periodo['mensal'][$mes]['quantidade'] += $quantidade;
        $relatorio_por_periodo['mensal'][$mes]['total'] += $subtotal;

        // Anual
        if (!isset($relatorio_por_periodo['anual'][$ano])) {
            $relatorio_por_periodo['anual'][$ano] = ['quantidade' => 0, 'total' => 0];
        }
        $relatorio_por_periodo['anual'][$ano]['quantidade'] += $quantidade;
        $relatorio_por_periodo['anual'][$ano]['total'] += $subtotal;
    }
}

// Lógica para gerar PDF
if (isset($_GET['gerar_pdf'])) {
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="relatorio_vendas_' . date('Ymd') . '.pdf"');
    
    // Gerar LaTeX
    $latex_content = <<<LATEX
\\documentclass[a4paper,12pt]{article}
\\usepackage[utf8]{inputenc}
\\usepackage[T1]{fontenc}
\\usepackage{lmodern}
\\usepackage{geometry}
\\geometry{margin=2cm}
\\usepackage{booktabs}
\\usepackage{longtable}
\\usepackage{pdflscape}
\\usepackage{amsmath}
\\usepackage{siunitx}
\\sisetup{output-decimal-marker={,}}
\\usepackage[brazilian]{babel}

\\begin{document}

\\begin{center}
    \\textbf{\\large Relatório de Vendas - Farmácia XYZ} \\\\
    Período: $data_inicio a $data_fim
\\end{center}

\\section*{Resumo Geral}
Total de vendas no período: Kz \\num{$total_periodo} \\\\
Quantidade total de itens vendidos: \\num{$quantidade_total_itens}

\\section*{Produtos Vendidos}
\\begin{longtable}{l r r}
    \\toprule
    \\textbf{Produto} & \\textbf{Quantidade} & \\textbf{Subtotal (Kz)} \\\\
    \\midrule
    \\endhead
LATEX;

    foreach ($produtos_vendidos as $nome => $dados) {
        $quantidade = $dados['quantidade'];
        $subtotal = number_format($dados['subtotal'], 2, ',', '.');
        $nome_escapado = str_replace(['&', '%', '$', '#', '_', '{', '}'], ['\&', '\%', '\$', '\#', '\_', '\{', '\}'], $nome);
        $latex_content .= "    $nome_escapado & \\num{$quantidade} & \\num{$subtotal} \\\\\n";
    }

    $latex_content .= <<<LATEX
    \\bottomrule
\\end{longtable}

\\section*{Vendas por Período}

\\subsection*{Diário}
\\begin{tabular}{l r r}
    \\toprule
    \\textbf{Data} & \\textbf{Quantidade} & \\textbf{Total (Kz)} \\\\
    \\midrule
LATEX;

    foreach ($relatorio_por_periodo['diario'] as $dia => $dados) {
        $total = number_format($dados['total'], 2, ',', '.');
        $latex_content .= "    $dia & \\num{$dados[quantidade]} & \\num{$total} \\\\\n";
    }

    $latex_content .= <<<LATEX
    \\bottomrule
\\end{tabular}

\\subsection*{Semanal}
\\begin{tabular}{l r r}
    \\toprule
    \\textbf{Semana} & \\textbf{Quantidade} & \\textbf{Total (Kz)} \\\\
    \\midrule
LATEX;

    foreach ($relatorio_por_periodo['semanal'] as $semana => $dados) {
        $total = number_format($dados['total'], 2, ',', '.');
        $latex_content .= "    $semana & \\num{$dados[quantidade]} & \\num{$total} \\\\\n";
    }

    $latex_content .= <<<LATEX
    \\bottomrule
\\end{tabular}

\\subsection*{Mensal}
\\begin{tabular}{l r r}
    \\toprule
    \\textbf{Mês} & \\textbf{Quantidade} & \\textbf{Total (Kz)} \\\\
    \\midrule
LATEX;

    foreach ($relatorio_por_periodo['mensal'] as $mes => $dados) {
        $total = number_format($dados['total'], 2, ',', '.');
        $latex_content .= "    $mes & \\num{$dados[quantidade]} & \\num{$total} \\\\\n";
    }

    $latex_content .= <<<LATEX
    \\bottomrule
\\end{tabular}

\\subsection*{Anual}
\\begin{tabular}{l r r}
    \\toprule
    \\textbf{Ano} & \\textbf{Quantidade} & \\textbf{Total (Kz)} \\\\
    \\midrule
LATEX;

    foreach ($relatorio_por_periodo['anual'] as $ano => $dados) {
        $total = number_format($dados['total'], 2, ',', '.');
        $latex_content .= "    $ano & \\num{$dados[quantidade]} & \\num{$total} \\\\\n";
    }

    $latex_content .= <<<LATEX
    \\bottomrule
\\end{tabular}

\\section*{Detalhes das Vendas}
\\begin{longtable}{l l r}
    \\toprule
    \\textbf{ID da Venda} & \\textbf{Data} & \\textbf{Total (Kz)} \\\\
    \\midrule
    \\endhead
LATEX;

    foreach ($vendas as $venda) {
        $total = number_format($venda['total'], 2, ',', '.');
        $latex_content .= "    {$venda['id']} & {$venda['data']} & \\num{$total} \\\\\n";
        $itens = buscarItensVenda($venda['id']);
        foreach ($itens as $item) {
            $nome_escapado = str_replace(['&', '%', '$', '#', '_', '{', '}'], ['\&', '\%', '\$', '\#', '\_', '\{', '\}'], $item['nome']);
            $subtotal = number_format($item['subtotal'], 2, ',', '.');
            $latex_content .= "    \\quad \\textit{$nome_escapado} & \\num{$item[quantidade]} & \\num{$subtotal} \\\\\n";
        }
    }

    $latex_content .= <<<LATEX
    \\bottomrule
\\end{longtable}

\\end{document}
LATEX;

    // Salvar arquivo LaTeX temporário
    $temp_file = sys_get_temp_dir() . '/relatorio_vendas_' . time() . '.tex';
    if (!file_put_contents($temp_file, $latex_content)) {
        logErro("Erro ao criar arquivo LaTeX temporário: $temp_file");
        header("Location: relatorios.php?msg=" . urlencode("Erro ao gerar o PDF."));
        exit;
    }

    // Compilar LaTeX para PDF usando latexmk
    $output_dir = sys_get_temp_dir();
    $command = "latexmk -pdf -pdflatex='pdflatex -interaction=nonstopmode' -outdir=$output_dir $temp_file 2>&1";
    exec($command, $output, $return_var);

    if ($return_var !== 0) {
        logErro("Erro ao gerar PDF: " . implode("\n", $output));
        header("Location: relatorios.php?msg=" . urlencode("Erro ao gerar o PDF."));
        exit;
    }

    // Enviar o PDF
    $pdf_file = $output_dir . '/' . basename($temp_file, '.tex') . '.pdf';
    if (file_exists($pdf_file)) {
        readfile($pdf_file);
        unlink($temp_file);
        unlink($pdf_file);
    } else {
        logErro("Arquivo PDF não encontrado: $pdf_file");
        header("Location: relatorios.php?msg=" . urlencode("Erro ao gerar o PDF."));
    }
    exit;
}

// Lógica para buscar os detalhes de uma venda via AJAX
if (isset($_GET['itens_venda_id'])) {
    header('Content-Type: application/json');
    $itens = buscarItensVenda($_GET['itens_venda_id']);
    echo json_encode($itens);
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Relatórios de Vendas - Farmácia XYZ</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
    <header>
        <h1>Farmácia XYZ</h1>
        <nav>
            <a href="index.php">Vendas</a>
            <a href="estoque.php">Estoque</a>
            <a href="relatorios.php">Relatórios</a>
            <button id="theme-toggle">Modo Escuro</button>
        </nav>
    </header>

    <main>
        <h2>Relatórios de Vendas</h2>
        <?php if (isset($_GET['msg'])) echo "<p class='mensagem'>" . htmlspecialchars($_GET['msg']) . "</p>"; ?>

        <div class="filtros-relatorios">
            <form method="GET" action="relatorios.php">
                <label for="data_inicio">Data Início:</label>
                <input type="date" name="data_inicio" id="data_inicio" value="<?= htmlspecialchars($data_inicio) ?>">
                <label for="data_fim">Data Fim:</label>
                <input type="date" name="data_fim" id="data_fim" value="<?= htmlspecialchars($data_fim) ?>">
                <button type="submit">Filtrar</button>
                <button type="button" onclick="window.location.href='relatorios.php?gerar_pdf=1&data_inicio=<?= htmlspecialchars($data_inicio) ?>&data_fim=<?= htmlspecialchars($data_fim) ?>'">Baixar PDF</button>
            </form>
        </div>

        <div class="resumo-relatorio">
            <h3>Total de Vendas no Período: Kz <?= number_format($total_periodo, 2, ',', '.') ?></h3>
            <h3>Quantidade Total de Itens Vendidos: <?= htmlspecialchars($quantidade_total_itens) ?></h3>
        </div>

        <!-- Resumo por Período -->
        <div class="relatorio-periodo">
            <h3>Resumo por Período</h3>
            <h4>Diário</h4>
            <table>
                <thead>
                    <tr>
                        <th>Data</th>
                        <th>Quantidade Vendida</th>
                        <th>Total (Kz)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($relatorio_por_periodo['diario'])): ?>
                    <tr>
                        <td colspan="3" style="text-align: center;">Nenhuma venda encontrada para o período.</td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($relatorio_por_periodo['diario'] as $dia => $dados): ?>
                    <tr>
                        <td><?= htmlspecialchars($dia) ?></td>
                        <td><?= htmlspecialchars($dados['quantidade']) ?></td>
                        <td>Kz <?= number_format($dados['total'], 2, ',', '.') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>

            <h4>Semanal</h4>
            <table>
                <thead>
                    <tr>
                        <th>Semana</th>
                        <th>Quantidade Vendida</th>
                        <th>Total (Kz)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($relatorio_por_periodo['semanal'])): ?>
                    <tr>
                        <td colspan="3" style="text-align: center;">Nenhuma venda encontrada para o período.</td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($relatorio_por_periodo['semanal'] as $semana => $dados): ?>
                    <tr>
                        <td><?= htmlspecialchars($semana) ?></td>
                        <td><?= htmlspecialchars($dados['quantidade']) ?></td>
                        <td>Kz <?= number_format($dados['total'], 2, ',', '.') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>

            <h4>Mensal</h4>
            <table>
                <thead>
                    <tr>
                        <th>Mês</th>
                        <th>Quantidade Vendida</th>
                        <th>Total (Kz)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($relatorio_por_periodo['mensal'])): ?>
                    <tr>
                        <td colspan="3" style="text-align: center;">Nenhuma venda encontrada para o período.</td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($relatorio_por_periodo['mensal'] as $mes => $dados): ?>
                    <tr>
                        <td><?= htmlspecialchars($mes) ?></td>
                        <td><?= htmlspecialchars($dados['quantidade']) ?></td>
                        <td>Kz <?= number_format($dados['total'], 2, ',', '.') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>

            <h4>Anual</h4>
            <table>
                <thead>
                    <tr>
                        <th>Ano</th>
                        <th>Quantidade Vendida</th>
                        <th>Total (Kz)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($relatorio_por_periodo['anual'])): ?>
                    <tr>
                        <td colspan="3" style="text-align: center;">Nenhuma venda encontrada para o período.</td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($relatorio_por_periodo['anual'] as $ano => $dados): ?>
                    <tr>
                        <td><?= htmlspecialchars($ano) ?></td>
                        <td><?= htmlspecialchars($dados['quantidade']) ?></td>
                        <td>Kz <?= number_format($dados['total'], 2, ',', '.') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Produtos Vendidos -->
        <div class="produtos-vendidos">
            <h3>Produtos Vendidos</h3>
            <table>
                <thead>
                    <tr>
                        <th>Produto</th>
                        <th>Quantidade</th>
                        <th>Subtotal (Kz)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($produtos_vendidos)): ?>
                    <tr>
                        <td colspan="3" style="text-align: center;">Nenhum produto vendido no período.</td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($produtos_vendidos as $nome => $dados): ?>
                    <tr>
                        <td><?= htmlspecialchars($nome) ?></td>
                        <td><?= htmlspecialchars($dados['quantidade']) ?></td>
                        <td>Kz <?= number_format($dados['subtotal'], 2, ',', '.') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Detalhes das Vendas -->
        <div class="tabela-relatorios">
            <h3>Detalhes das Vendas</h3>
            <table>
                <thead>
                    <tr>
                        <th>ID da Venda</th>
                        <th>Data</th>
                        <th>Total da Venda</th>
                        <th>Detalhes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($vendas)): ?>
                    <tr>
                        <td colspan="4" style="text-align: center;">Nenhuma venda encontrada no período.</td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($vendas as $venda): ?>
                    <tr>
                        <td><?= htmlspecialchars($venda['id']) ?></td>
                        <td><?= htmlspecialchars($venda['data']) ?></td>
                        <td>Kz <?= number_format($venda['total'], 2, ',', '.') ?></td>
                        <td>
                            <button onclick="mostrarDetalhes(<?= $venda['id'] ?>)">Ver Itens</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
    <script src="js/main.js"></script>
    <script>
        function mostrarDetalhes(vendaId) {
            fetch(`relatorios.php?itens_venda_id=${vendaId}`)
                .then(response => response.json())
                .then(itens => {
                    let detalhes = 'Itens:\n';
                    if (itens.length > 0) {
                        itens.forEach(item => {
                            detalhes += `- ${item.nome}: ${item.quantidade} x Kz ${parseFloat(item.subtotal / item.quantidade).toFixed(2)} = Kz ${parseFloat(item.subtotal).toFixed(2)}\n`;
                        });
                    } else {
                        detalhes = "Nenhum item encontrado para esta venda.";
                    }
                    alert(detalhes);
                })
                .catch(error => {
                    console.error('Erro ao buscar itens:', error);
                    alert('Erro ao carregar os itens da venda.');
                });
        }
    </script>
</body>
</html>