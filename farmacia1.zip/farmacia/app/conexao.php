<?php
$servername = "localhost";
$username = "root"; // Altere se o seu usuário do MySQL for diferente
$password = "1234"; // Altere se tiver senha
$dbname = "farmacia";

// Cria a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}
?>