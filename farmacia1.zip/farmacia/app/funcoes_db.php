<?php
require_once 'conexao.php';

// --- Funções de Produto ---
function buscarProdutos() {
    global $conn;
    $sql = "SELECT * FROM produtos ORDER BY nome ASC";
    $result = $conn->query($sql);
    $produtos = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $produtos[] = $row;
        }
    }
    return $produtos;
}

function buscarProdutoPorTermo($termo) {
    global $conn;
    $sql = "SELECT id, nome, preco, quantidade, codigo_barras FROM produtos WHERE nome LIKE ? OR codigo_barras = ?";
    $stmt = $conn->prepare($sql);
    $termo_like = "%" . $termo . "%";
    $stmt->bind_param("ss", $termo_like, $termo);
    $stmt->execute();
    $result = $stmt->get_result();
    $produtos = [];
    while ($row = $result->fetch_assoc()) {
        $produtos[] = $row;
    }
    return $produtos; // Retorna um array de produtos
}

function adicionarProduto($nome, $preco, $quantidade, $descricao = '', $codigo_barras = null) {
    global $conn;
    $sql = "INSERT INTO produtos (nome, preco, quantidade, descricao, codigo_barras) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sdisi", $nome, $preco, $quantidade, $descricao, $codigo_barras);
    return $stmt->execute();
}

function atualizarProduto($id, $nome, $preco, $quantidade, $descricao = '', $codigo_barras = null) {
    global $conn;
    $sql = "UPDATE produtos SET nome=?, preco=?, quantidade=?, descricao=?, codigo_barras=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sdisii", $nome, $preco, $quantidade, $descricao, $codigo_barras, $id);
    return $stmt->execute();
}

function deletarProduto($id) {
    global $conn;
    $sql = "DELETE FROM produtos WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    return $stmt->execute();
}

// --- Funções de Venda ---
function registrarVenda($total, $itens_venda) {
    global $conn;
    $conn->begin_transaction();
    try {
        $sql_venda = "INSERT INTO vendas (data, total) VALUES (NOW(), ?)";
        $stmt_venda = $conn->prepare($sql_venda);
        $stmt_venda->bind_param("d", $total);
        $stmt_venda->execute();
        $venda_id = $conn->insert_id;

        foreach ($itens_venda as $item) {
            $sql_item = "INSERT INTO itens_venda (venda_id, produto_id, quantidade, subtotal) VALUES (?, ?, ?, ?)";
            $stmt_item = $conn->prepare($sql_item);
            $stmt_item->bind_param("iiid", $venda_id, $item['produto_id'], $item['quantidade'], $item['subtotal']);
            $stmt_item->execute();

            $sql_estoque = "UPDATE produtos SET quantidade = quantidade - ? WHERE id = ?";
            $stmt_estoque = $conn->prepare($sql_estoque);
            $stmt_estoque->bind_param("ii", $item['quantidade'], $item['produto_id']);
            $stmt_estoque->execute();
        }

        $conn->commit();
        return true;
    } catch (mysqli_sql_exception $e) {
        $conn->rollback();
        return false;
    }
}

function buscarVendasPorPeriodo($data_inicio, $data_fim) {
    global $conn;
    $sql = "SELECT * FROM vendas WHERE data BETWEEN ? AND ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $data_inicio, $data_fim);
    $stmt->execute();
    $result = $stmt->get_result();
    $vendas = [];
    while($row = $result->fetch_assoc()) {
        $vendas[] = $row;
    }
    return $vendas;
}

function buscarItensVenda($venda_id) {
    global $conn;
    $sql = "SELECT p.nome, iv.quantidade, iv.subtotal FROM itens_venda AS iv JOIN produtos AS p ON iv.produto_id = p.id WHERE iv.venda_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $venda_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $itens = [];
    while($row = $result->fetch_assoc()) {
        $itens[] = $row;
    }
    return $itens;
}
?>