<?php
require_once 'app/funcoes_db.php';

// Configura o cabeçalho padrão como HTML
header('Content-Type: text/html; charset=UTF-8');

// Lógica para adicionar item via POST (AJAX request)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['termo_busca'])) {
    header('Content-Type: application/json; charset=UTF-8');
    
    $termo = filter_input(INPUT_POST, 'termo_busca', FILTER_SANITIZE_STRING);
    if (empty($termo)) {
        echo json_encode(['status' => 'error', 'message' => 'Termo de busca inválido']);
        exit;
    }

    $produtos = buscarProdutoPorTermo($termo); // Chama a função que retorna múltiplos produtos
    if (empty($produtos)) {
        echo json_encode(['status' => 'error', 'message' => 'Nenhum produto encontrado']);
    } else {
        echo json_encode(['status' => 'success', 'data' => $produtos]);
    }
    exit;
}

// Lógica para finalizar a venda via JSON (AJAX request)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty(file_get_contents('php://input'))) {
    header('Content-Type: application/json; charset=UTF-8');
    
    $data = json_decode(file_get_contents('php://input'), true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo json_encode(['status' => 'error', 'message' => 'Erro ao processar JSON']);
        exit;
    }

    if (isset($data['finalizar_venda']) && $data['finalizar_venda'] && isset($data['total']) && isset($data['itens'])) {
        $total = filter_var($data['total'], FILTER_VALIDATE_FLOAT);
        $itens = $data['itens'];

        if ($total === false || !is_array($itens) || empty($itens)) {
            echo json_encode(['status' => 'error', 'message' => 'Dados inválidos']);
            exit;
        }

        $itens_para_db = [];
        foreach ($itens as $item) {
            if (
                !isset($item['id']) || !isset($item['quantidade']) || !isset($item['preco']) ||
                !filter_var($item['id'], FILTER_VALIDATE_INT) ||
                !filter_var($item['quantidade'], FILTER_VALIDATE_INT) ||
                !filter_var($item['preco'], FILTER_VALIDATE_FLOAT)
            ) {
                echo json_encode(['status' => 'error', 'message' => 'Item inválido']);
                exit;
            }

            $itens_para_db[] = [
                'produto_id' => (int)$item['id'],
                'quantidade' => (int)$item['quantidade'],
                'subtotal' => (float)$item['preco'] * (int)$item['quantidade']
            ];
        }

        if (registrarVenda($total, $itens_para_db)) {
            echo json_encode(['status' => 'success', 'message' => 'Venda registrada com sucesso!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Erro ao registrar a venda.']);
        }
        exit;
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Parâmetros insuficientes para finalizar a venda']);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Sistema de Vendas - Farmácia XYZ</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
    <header>
        <h1>Farmácia XYZ</h1>
        <nav>
            <a href="index.php">Vendas</a>
            <a href="estoque.php">Estoque</a>
            <a href="relatorios.php">Relatórios</a>
            <button id="theme-toggle">Modo Escuro</button>
        </nav>
    </header>
    <main>
        <h2>Tela de Vendas</h2>
        <div class="venda-container">
            <div class="busca-produto">
                <input type="text" id="termo-busca" placeholder="Nome ou Código de Barras">
                <button id="btn-adicionar">Adicionar</button>
            </div>
            <div class="tabela-venda">
                <table>
                    <thead>
                        <tr>
                            <th>Produto</th>
                            <th>Preço</th>
                            <th>Quantidade</th>
                            <th>Subtotal</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody id="tabela-itens"></tbody>
                </table>
            </div>
            <div class="resumo-venda">
                <p>Total: Kz <span id="total-venda">0.00</span></p>
                <button id="btn-finalizar">Finalizar Venda</button>
            </div>
        </div>
    </main>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const termoBusca = document.getElementById('termo-busca');
            const btnAdicionar = document.getElementById('btn-adicionar');
            const tabelaItens = document.getElementById('tabela-itens');
            const totalVenda = document.getElementById('total-venda');

            // Função para atualizar o total da venda
            function atualizarTotal() {
                let total = 0;
                const linhas = tabelaItens.querySelectorAll('tr');
                linhas.forEach(linha => {
                    const subtotal = parseFloat(linha.querySelector('.subtotal').textContent);
                    total += subtotal;
                });
                totalVenda.textContent = total.toFixed(2);
            }

            // Função para adicionar produto à tabela
            function adicionarProdutoNaTabela(produto) {
                // Escapar caracteres especiais no nome para evitar quebras no HTML
                const nomeEscapado = produto.nome.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
                // Garantir que o ID seja tratado como string para suportar qualquer tamanho
                const idProduto = String(produto.id);
                const row = tabelaItens.insertRow();
                row.dataset.id = idProduto; // Armazena o ID do produto
                // Definir quantidade inicial como 1 e mínimo como 1
                const quantidadeInicial = 1;
                const quantidadeMaxima = produto.quantidade > 0 ? produto.quantidade : 1;
                row.innerHTML = `
                    <td>${nomeEscapado}</td>
                    <td>${parseFloat(produto.preco).toFixed(2)}</td>
                    <td><input type="number" class="quantidade" value="${quantidadeInicial}" min="1" max="${quantidadeMaxima}"></td>
                    <td class="subtotal">${(parseFloat(produto.preco) * quantidadeInicial).toFixed(2)}</td>
                    <td><button class="remover">Remover</button></td>
                `;

                // Atualizar subtotal quando a quantidade mudar
                const inputQuantidade = row.querySelector('.quantidade');
                inputQuantidade.addEventListener('input', function () {
                    let quantidade = parseInt(this.value);
                    // Garantir que a quantidade esteja dentro dos limites
                    if (quantidade < 1) quantidade = 1;
                    if (quantidade > quantidadeMaxima) quantidade = quantidadeMaxima;
                    this.value = quantidade;
                    const preco = parseFloat(produto.preco);
                    const subtotalCell = row.querySelector('.subtotal');
                    subtotalCell.textContent = (preco * quantidade).toFixed(2);
                    atualizarTotal();
                });

                // Remover item
                const btnRemover = row.querySelector('.remover');
                btnRemover.addEventListener('click', function () {
                    row.remove();
                    atualizarTotal();
                });

                atualizarTotal();
            }

            // Função para buscar produto
            function buscarProduto(termo) {
                if (!termo) {
                    tabelaItens.innerHTML = ''; // Limpa a tabela se o termo estiver vazio
                    atualizarTotal();
                    return;
                }

                fetch('', { // Requisição para o mesmo arquivo (index.php)
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `termo_busca=${encodeURIComponent(termo)}`
                })
                .then(response => response.json())
                .then(data => {
                    console.log('Resposta do servidor:', data); // Para depuração
                    tabelaItens.innerHTML = ''; // Limpa a tabela antes de adicionar novos resultados
                    if (data.status === 'success' && data.data.length > 0) {
                        // Adiciona todos os produtos encontrados
                        data.data.forEach(produto => {
                            adicionarProdutoNaTabela(produto);
                        });
                        termoBusca.focus(); // Mantém o foco para continuar digitando
                    } else {
                        atualizarTotal(); // Atualiza o total (zero se a tabela estiver vazia)
                        // Não exibe alerta para busca incremental, apenas para buscas manuais
                    }
                })
                .catch(error => {
                    console.error('Erro na requisição:', error);
                    tabelaItens.innerHTML = ''; // Limpa a tabela em caso de erro
                    atualizarTotal();
                    // Não exibe alerta para busca incremental
                    termoBusca.focus();
                });
            }

            // Função para busca manual (com alerta em caso de erro)
            function buscarProdutoManual(termo) {
                if (!termo) {
                    alert('Por favor, insira um código de barras ou nome do produto.');
                    return;
                }

                fetch('', { // Requisição para o mesmo arquivo (index.php)
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `termo_busca=${encodeURIComponent(termo)}`
                })
                .then(response => response.json())
                .then(data => {
                    console.log('Resposta do servidor:', data); // Para depuração
                    tabelaItens.innerHTML = ''; // Limpa a tabela antes de adicionar novos resultados
                    if (data.status === 'success' && data.data.length > 0) {
                        // Adiciona todos os produtos encontrados
                        data.data.forEach(produto => {
                            adicionarProdutoNaTabela(produto);
                        });
                        termoBusca.value = ''; // Limpa o campo de busca
                        termoBusca.focus(); // Mantém o foco para o próximo scan
                    } else {
                        alert(data.message || 'Nenhum produto encontrado.');
                        termoBusca.value = '';
                        termoBusca.focus();
                    }
                })
                .catch(error => {
                    console.error('Erro na requisição:', error);
                    alert('Erro ao buscar produto.');
                    termoBusca.value = '';
                    termoBusca.focus();
                });
            }

            // Debounce para busca incremental
            let typingTimer;
            const debounceDelay = 300; // Atraso de 300ms para limitar requisições

            termoBusca.addEventListener('input', function () {
                clearTimeout(typingTimer);
                const termo = this.value.trim();
                typingTimer = setTimeout(() => {
                    buscarProduto(termo);
                }, debounceDelay);
            });

            // Suporte para scanner e busca manual via Enter
            termoBusca.addEventListener('keydown', function (event) {
                if (event.key === 'Enter') {
                    event.preventDefault(); // Evita comportamento padrão do Enter
                    const termo = this.value.trim();
                    clearTimeout(typingTimer); // Cancela busca incremental
                    buscarProdutoManual(termo);
                }
            });

            // Evento de clique no botão Adicionar (para busca manual)
            btnAdicionar.addEventListener('click', function () {
                const termo = termoBusca.value.trim();
                clearTimeout(typingTimer); // Cancela busca incremental
                buscarProdutoManual(termo);
            });

            // Evento para finalizar a venda
            document.getElementById('btn-finalizar').addEventListener('click', function () {
                const linhas = tabelaItens.querySelectorAll('tr');
                const itens = [];
                let total = 0;

                linhas.forEach(linha => {
                    const id = parseInt(linha.dataset.id);
                    const quantidade = parseInt(linha.querySelector('.quantidade').value);
                    const preco = parseFloat(linha.cells[1].textContent);
                    const subtotal = parseFloat(linha.querySelector('.subtotal').textContent);
                    itens.push({ id, quantidade, preco });
                    total += subtotal;
                });

                if (itens.length === 0) {
                    alert('Nenhum item na venda.');
                    return;
                }

                fetch('', { // Requisição para o mesmo arquivo (index.php)
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ finalizar_venda: true, total, itens })
                })
                .then(response => response.json())
                .then(data => {
                    alert(data.message);
                    if (data.status === 'success') {
                        tabelaItens.innerHTML = ''; // Limpa a tabela
                        totalVenda.textContent = '0.00';
                        termoBusca.focus(); // Foco no campo para o próximo scan
                    }
                })
                .catch(error => {
                    console.error('Erro ao finalizar venda:', error);
                    alert('Erro ao finalizar a venda.');
                });
            });

            // Foco inicial no campo de busca
            termoBusca.focus();
        });
    </script>
</body>
</html>