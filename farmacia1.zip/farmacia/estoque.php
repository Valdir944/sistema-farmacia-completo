<?php
require_once 'app/funcoes_db.php';
$mensagem = '';
$produtos = buscarProdutos();

// Função para registrar erros em um log (opcional)
function logErro($mensagemErro) {
    error_log(date('[Y-m-d H:i:s] ') . $mensagemErro . PHP_EOL, 3, 'erros.log');
}

// Lógica para adicionar ou atualizar um produto
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['form_estoque'])) {
    $id = $_POST['produto_id'] ?? null;
    $nome = trim($_POST['nome'] ?? '');
    $preco = filter_var($_POST['preco'] ?? 0, FILTER_VALIDATE_FLOAT);
    $quantidade = filter_var($_POST['quantidade'] ?? 0, FILTER_VALIDATE_INT);
    $descricao = trim($_POST['descricao'] ?? '');
    $codigo = trim($_POST['codigo_barras'] ?? '');

    // Validação básica de entrada
    if (empty($nome) || $preco === false || $preco <= 0 || $quantidade === false || $quantidade < 0) {
        logErro("Dados inválidos ao adicionar/atualizar produto: Nome: $nome, Preço: $preco, Quantidade: $quantidade");
        header("Location: estoque.php");
        exit;
    }

    if ($id) {
        if (atualizarProduto($id, $nome, $preco, $quantidade, $descricao, $codigo)) {
            $mensagem = "Produto atualizado com sucesso!";
        } else {
            logErro("Erro ao atualizar produto ID: $id");
            // Não define mensagem de erro para o usuário
        }
    } else {
        if (adicionarProduto($nome, $preco, $quantidade, $descricao, $codigo)) {
            $mensagem = "Produto adicionado com sucesso!";
        } else {
            logErro("Erro ao adicionar produto: $nome, Código de barras: $codigo");
            // Não define mensagem de erro para o usuário
        }
    }
    header("Location: estoque.php" . ($mensagem ? "?msg=" . urlencode($mensagem) : ""));
    exit;
}

// Lógica para deletar um produto
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['delete_id'])) {
    $id = filter_var($_GET['delete_id'], FILTER_VALIDATE_INT);
    if ($id !== false && $id > 0) {
        if (deletarProduto($id)) {
            $mensagem = "Produto deletado com sucesso!";
        } else {
            logErro("Erro ao deletar produto ID: $id");
            // Não define mensagem de erro para o usuário
        }
    } else {
        logErro("ID inválido para exclusão: " . $_GET['delete_id']);
    }
    header("Location: estoque.php" . ($mensagem ? "?msg=" . urlencode($mensagem) : ""));
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Gerenciamento de Estoque - Farmácia XYZ</title>
    <link rel="stylesheet" href="css/estilo.css"> <!-- Corrigido o caminho para css/estilo.css, assumindo estrutura padrão -->
</head>
<body>
    <header>
        <h1>Farmácia XYZ</h1>
        <nav>
            <a href="index.php">Vendas</a>
            <a href="estoque.php">Estoque</a>
            <a href="relatorios.php">Relatórios</a>
            <button id="theme-toggle">Modo Escuro</button>
        </nav>
    </header>

    <main>
        <h2>Gerenciar Estoque</h2>
        <?php if (isset($_GET['msg'])) echo "<p class='mensagem'>" . htmlspecialchars($_GET['msg']) . "</p>"; ?>

        <!-- Notificação de estoque esgotado -->
        <?php
        $produtosEsgotados = array_filter($produtos, function($produto) {
            return $produto['quantidade'] == 0;
        });
        if (!empty($produtosEsgotados)) {
            echo "<div class='notificacao-esgotado'>";
            echo "<p><strong>Atenção:</strong> Os seguintes produtos estão com estoque esgotado:</p>";
            echo "<ul>";
            foreach ($produtosEsgotados as $produto) {
                echo "<li>" . htmlspecialchars($produto['nome']) . "</li>";
            }
            echo "</ul>";
            echo "</div>";
        }
        ?>

        <form method="POST" action="estoque.php" class="form-estoque">
            <input type="hidden" name="form_estoque">
            <input type="hidden" name="produto_id" id="produto_id">
            
            <input type="text" name="nome" id="nome" placeholder="Nome do Produto" required>
            <input type="number" step="0.01" name="preco" id="preco" placeholder="Preço" min="0.01" required>
            <input type="number" name="quantidade" id="quantidade" placeholder="Quantidade" min="0" required>
            <input type="text" name="codigo_barras" id="codigo_barras" placeholder="Código de Barras">
            <textarea name="descricao" id="descricao" placeholder="Descrição"></textarea>
            
            <button type="submit" id="btn_salvar">Salvar</button>
            <button type="button" id="btn_cancelar" style="display:none;">Cancelar</button>
        </form>

        <div class="tabela-estoque">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Preço</th>
                        <th>Quantidade</th>
                        <th>Cód. Barras</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($produtos)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center;">Nenhum produto encontrado no estoque.</td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($produtos as $produto): ?>
                    <tr>
                        <td><?= htmlspecialchars($produto['id']) ?></td>
                        <td><?= htmlspecialchars($produto['nome']) ?></td>
                        <td>Kz <?= number_format($produto['preco'], 2, ',', '.') ?></td>
                        <td><?= htmlspecialchars($produto['quantidade']) ?></td>
                        <td><?= htmlspecialchars($produto['codigo_barras']) ?></td>
                        <td><?= $produto['quantidade'] == 0 ? '<span class="status-esgotado">Esgotado</span>' : 'Disponível' ?></td>
                        <td>
                            <button class="btn-editar" data-produto='<?= json_encode($produto) ?>'>Editar</button>
                            <a href="estoque.php?delete_id=<?= $produto['id'] ?>" onclick="return confirm('Tem certeza que deseja deletar este produto?');">Excluir</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
    <script src="js/main.js"></script>
    <script>
        document.querySelectorAll('.btn-editar').forEach(button => {
            button.addEventListener('click', function() {
                const produto = JSON.parse(this.dataset.produto);
                document.getElementById('produto_id').value = produto.id;
                document.getElementById('nome').value = produto.nome;
                document.getElementById('preco').value = produto.preco;
                document.getElementById('quantidade').value = produto.quantidade;
                document.getElementById('codigo_barras').value = produto.codigo_barras;
                document.getElementById('descricao').value = produto.descricao;
                document.getElementById('btn_salvar').innerText = 'Atualizar';
                document.getElementById('btn_cancelar').style.display = 'inline';
            });
        });

        document.getElementById('btn_cancelar').addEventListener('click', function() {
            document.getElementById('produto_id').value = '';
            document.getElementById('nome').value = '';
            document.getElementById('preco').value = '';
            document.getElementById('quantidade').value = '';
            document.getElementById('codigo_barras').value = '';
            document.getElementById('descricao').value = '';
            document.getElementById('btn_salvar').innerText = 'Salvar';
            this.style.display = 'none';
        });
    </script>
</body>
</html>