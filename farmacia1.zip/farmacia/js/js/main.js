document.getElementById('theme-toggle').addEventListener('click', function() {
    document.body.classList.toggle('dark-mode');
    const isDarkMode = document.body.classList.contains('dark-mode');
    this.innerText = isDarkMode ? 'Modo Claro' : 'Modo Escuro';
});
