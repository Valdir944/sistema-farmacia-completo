document.addEventListener('DOMContentLoaded', function () {
    const termoBusca = document.getElementById('termo-busca');
    const btnAdicionar = document.getElementById('btn-adicionar');
    const tabelaItens = document.getElementById('tabela-itens');
    const totalVenda = document.getElementById('total-venda');

    // Função para atualizar o total da venda
    function atualizarTotal() {
        let total = 0;
        const linhas = tabelaItens.querySelectorAll('tr');
        linhas.forEach(linha => {
            const subtotal = parseFloat(linha.querySelector('.subtotal').textContent);
            total += subtotal;
        });
        totalVenda.textContent = total.toFixed(2);
    }

    // Função para adicionar produto à tabela
    function adicionarProdutoNaTabela(produto) {
        const row = tabelaItens.insertRow();
        row.dataset.id = produto.id; // Armazena o ID do produto
        row.innerHTML = `
            <td>${produto.nome}</td>
            <td>${parseFloat(produto.preco).toFixed(2)}</td>
            <td><input type="number" class="quantidade" value="1" min="1" max="${produto.quantidade}"></td>
            <td class="subtotal">${(produto.preco * 1).toFixed(2)}</td>
            <td><button class="remover">Remover</button></td>
        `;

        // Atualizar subtotal quando a quantidade mudar
        const inputQuantidade = row.querySelector('.quantidade');
        inputQuantidade.addEventListener('input', function () {
            const quantidade = parseInt(this.value);
            const preco = parseFloat(produto.preco);
            const subtotalCell = row.querySelector('.subtotal');
            subtotalCell.textContent = (preco * quantidade).toFixed(2);
            atualizarTotal();
        });

        // Remover item
        const btnRemover = row.querySelector('.remover');
        btnRemover.addEventListener('click', function () {
            row.remove();
            atualizarTotal();
        });

        atualizarTotal();
    }

    // Evento de clique no botão Adicionar
    btnAdicionar.addEventListener('click', function () {
        const termo = termoBusca.value.trim();
        if (!termo) {
            alert('Por favor, insira um nome ou código de barras.');
            return;
        }

        fetch('index.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `termo_busca=${encodeURIComponent(termo)}`
        })
        .then(response => response.json())
        .then(data => {
            console.log('Resposta do servidor:', data); // Para depuração
            if (data.status === 'success' && data.data.length > 0) {
                // Adiciona o primeiro produto encontrado (ou implemente uma seleção)
                const produto = data.data[0];
                adicionarProdutoNaTabela(produto);
                termoBusca.value = ''; // Limpa o campo de busca
            } else {
                alert(data.message || 'Nenhum produto encontrado.');
            }
        })
        .catch(error => {
            console.error('Erro na requisição:', error);
            alert('Erro ao buscar produto.');
        });
    });

    // Evento para finalizar a venda (exemplo básico)
    document.getElementById('btn-finalizar').addEventListener('click', function () {
        const linhas = tabelaItens.querySelectorAll('tr');
        const itens = [];
        let total = 0;

        linhas.forEach(linha => {
            const id = parseInt(linha.dataset.id);
            const quantidade = parseInt(linha.querySelector('.quantidade').value);
            const preco = parseFloat(linha.cells[1].textContent);
            const subtotal = parseFloat(linha.querySelector('.subtotal').textContent);
            itens.push({ id, quantidade, preco });
            total += subtotal;
        });

        if (itens.length === 0) {
            alert('Nenhum item na venda.');
            return;
        }

        fetch('index.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ finalizar_venda: true, total, itens })
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            if (data.status === 'success') {
                tabelaItens.innerHTML = ''; // Limpa a tabela
                totalVenda.textContent = '0.00';
            }
        })
        .catch(error => {
            console.error('Erro ao finalizar venda:', error);
            alert('Erro ao finalizar a venda.');
        });
    });
});